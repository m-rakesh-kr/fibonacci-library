from setuptools import setup

setup(
    name='fibonacci-library',
    version='0.1',
    author="Rakesh Kumar",
    description="A Simple Python library for generate fibonacci series",
    packages=['fibonacci'],
)
